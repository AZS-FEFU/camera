from .license_plate import license_plate_router

__all__ = ["license_plate_router"]